

let tempChart = document.getElementById("tempChart");

var chartColors = {
    red: 'rgb(255, 99, 132)',
    orange: 'rgb(255, 159, 64)',
    yellow: 'rgb(255, 205, 86)',
    green: 'rgb(75, 192, 192)',
    blue: 'rgb(54, 162, 235)',
    purple: 'rgb(153, 102, 255)',
    grey: 'rgb(231,233,237)'
  };

let tempData = {
// labels: ['Дата', 'Температура'],
    datasets: [{
        label: "Дата",
        borderColor: chartColors.blue,
        backgroundColor: chartColors.red,
        data: [
            ['18-03-2024', 0],
            ['19-03-2024', 1],
            ['20-03-2024', -2],
            ['21-03-2024', -4],
            ['22-03-2024', -3],
            ['23-03-2024', -1]
        ],

    }]
};

let chartOptions = {
legend: {
    display: true,
    position: 'top',
    labels: {
        boxWidth: 80,
        fontColor: 'black',
    },
    

},

};

lineChart = new Chart(tempChart, {
    type: 'line',
    data: tempData,
    options: chartOptions
});
    